#include "thirdpage.h"
#include "ui_thirdpage.h"

#include <iostream>
#include <fstream>
#include <QMessageBox>
#include <vector>

using namespace std;

thirdPage::thirdPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::thirdPage)
{
    ui->setupUi(this);
}

thirdPage::~thirdPage()
{
    delete ui;
}


bool is_answer_valid1(QString input){
    if(input == "0" || input == "1"){
        return true;
    }
    return false;
}

int trytocatch(QString input, Ui::thirdPage* var){
    bool ret;

    try{
    ret = is_answer_valid1(input);
    }
    catch (string msg){
    var->label_inva->setText("this input is not accepted");
    }
    return ret;
}


void thirdPage::on_pushButton_clicked()
{
    int count =0;

    bool ret;

    ret = trytocatch(ui->input1->toPlainText(), ui);
    ret = trytocatch(ui->input2->toPlainText(), ui);
    ret = trytocatch(ui->input3->toPlainText(), ui);
    ret = trytocatch(ui->input4->toPlainText(), ui);
    ret = trytocatch(ui->input5->toPlainText(), ui);
    ret = trytocatch(ui->input6->toPlainText(), ui);

    if (ui->input1->toPlainText()=="0"){
        count +=1;
       // ui->fact1->setText("Nice!");
    }
    if(ui->input2->toPlainText()=="1"){
        count+=1;
    }
    if(ui->input3->toPlainText()=="1"){
        count+=1;
    }
    if(ui->input4->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input5->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input6->toPlainText()=="1"){
        count+=1;
    }

    storage.push_back(count);

    if(count >=4){
       ui->score->setText("nice!");
     }
    else
     {
        ui->score->setText("you shuold practice!");

//       ui->score->setText("you shuold practice! your score is: " + QString::number(count));
      }

}


void thirdPage::on_save_clicked()
{
    //ifstream in;
    ofstream out;
    out.open("save.txt");

    for(int i = 0; i < storage.size();i++){
        out << "Round 1: your score is: " << storage[i] << endl;
    }

    QMessageBox::information(this, "save", "Your score is save!");

    out.close();
}


