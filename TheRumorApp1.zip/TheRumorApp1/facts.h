#ifndef FACTS_H
#define FACTS_H


#include <QDialog>
#include <vector>
#include <iostream>
#include <fstream>
#include <QMessageBox>

using namespace std;

namespace Ui {
class facts;

class baseFacts{
private:
    int count = 0;

public:
    int getC(){
        return count;
    }

    void setC(int c){
        this->count=c;
    }
};


}

class facts : public QDialog, Ui::baseFacts
{
    Q_OBJECT

public:
    explicit facts(QWidget *parent = nullptr);
    ~facts();
   vector<int> storage;


private slots:
    void on_pushButton_clicked();
    void on_save_clicked();
    void on_pushButton_2_clicked();


private:
    Ui::facts *ui;
};


#endif // FACTS_H

