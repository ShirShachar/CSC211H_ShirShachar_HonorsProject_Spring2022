#ifndef FACTS_H
#define FACTS_H


#include <QDialog>
#include <vector>
#include <iostream>
#include <fstream>
#include <QMessageBox>

using namespace std;

namespace Ui {
class facts;
}

class facts : public QDialog
{
    Q_OBJECT

public:
    explicit facts(QWidget *parent = nullptr);
    ~facts();
   int count;
   vector<int> storage;


private slots:
    void on_pushButton_clicked();
    void on_save_clicked();
    void on_pushButton_2_clicked();


private:
    Ui::facts *ui;
};


#endif // FACTS_H

