#ifndef THIRDPAGE_H
#define THIRDPAGE_H

#include <QDialog>
#include <vector>
#include "secondpage.h"

namespace Ui {
class thirdPage;
}

class thirdPage : public QDialog
{
    Q_OBJECT

public:
    explicit thirdPage(QWidget *parent = nullptr);
    ~thirdPage();
     vector<int> storage;

private slots:
    void on_pushButton_clicked();
    void on_save_clicked();


private:
    Ui::thirdPage *ui;
};

#endif // THIRDPAGE_H
