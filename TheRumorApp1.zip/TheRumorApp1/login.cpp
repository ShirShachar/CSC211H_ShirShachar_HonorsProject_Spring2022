#include "login.h"
#include "ui_login.h"
#include <QMessageBox>
#include "about.h"
#include "facts.h"
#include "information.h"
#include "mainwindow.h"

login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    information information;
    information.setModal(true);
    information.exec();
}


void login::on_aboutpushbutton_2_clicked()
{
    about about;
    about.setModal(true);
    about.exec();
}


void login::on_pushButton_5_clicked()
{
    facts facts;
    facts.setModal(true);
    facts.exec();
}

