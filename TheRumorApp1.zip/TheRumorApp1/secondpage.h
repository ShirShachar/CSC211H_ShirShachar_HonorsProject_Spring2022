#ifndef SECONDPAGE_H
#define SECONDPAGE_H
#include "facts.h"
#include <QDialog>
#include <fstream>
#include <vector>

using namespace std;

namespace Ui {
class secondPage;
}


class secondPage : public QDialog
{
    Q_OBJECT

public:
   explicit secondPage(QWidget *parent = nullptr);
    ~secondPage();
    int count;
    vector<int> storage;

private slots:
    void on_pushButton_clicked();
    void on_save_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::secondPage *ui;
};

#endif // SECONDPAGE_H
