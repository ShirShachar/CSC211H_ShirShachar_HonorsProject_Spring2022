/*#include "facts.h"
#include "ui_facts.h"
#include "secondpage.h"
#include <QMessageBox>

facts::facts(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::facts)
{
    ui->setupUi(this);
}

facts::~facts()
{
    delete ui;
}


bool is_answer_valid(QString input){
    if(input == "0" || input == "1"){
        return true;
    }
    throw string ("this input is not accepted");
    return false;
}



void facts::on_pushButton_clicked()
{
    int count =0;

    bool ret;

    try{
    ret = is_answer_valid(ui->input1->toPlainText());
    }
    catch (string msg){
     ui->score->setText("this input is not accepted");
    }

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    ret = is_answer_valid(ui->input2->toPlainText());

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    ret = is_answer_valid(ui->input3->toPlainText());

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    ret = is_answer_valid(ui->input11->toPlainText());

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    ret = is_answer_valid(ui->input12->toPlainText());

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    ret = is_answer_valid(ui->input13->toPlainText());

    if (ret == false){
        ui->score->setText("There is an invalide input");
        return;
    }

    if (ui->input1->toPlainText()=="1"){
        count +=1;
       // ui->fact1->setText("Nice!");
    }
    if(ui->input2->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input3->toPlainText()=="1"){
        count+=1;
    }
    if(ui->input11->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input12->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input13->toPlainText()=="0"){
        count+=1;
    }

    storage.push_back(count);

    if(count >=4){
       ui->score->setText("nice!");
     }
    else
     {
       ui->score->setText(QString::number(count));
      }


}


void facts::on_save_clicked()
{
    ofstream out;
    out.open("save.txt");

    for(int i = 0; i < storage.size();i++){
        out << "your score is: " << storage[i] << endl;
    }

    QMessageBox::information(this, "save", "Your score is save!");

    out.close();
}


void facts::on_pushButton_2_clicked()
{
    secondPage secondpage;
    secondpage.setModal(true);
    secondpage.exec();
}

*/
