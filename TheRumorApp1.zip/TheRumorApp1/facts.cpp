#include "facts.h"
#include "ui_facts.h"
#include "secondpage.h"
#include <QString>

facts::facts(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::facts)
{
    ui->setupUi(this);
}

facts::~facts()
{
    delete ui;
}


bool is_answer_valid(QString input){
    if(input == "0" || input == "1"){
        return true;
    }
    throw string ("this input is not accepted");
    return false;
}


int trytocatch(QString input, Ui::facts* var){
    bool ret;

    try{
    ret = is_answer_valid(input);
    }
    catch (string msg){
    var->catch_2->setText("this input is not accepted");
    }
    return ret;
}


void facts::on_pushButton_clicked()
{
    bool ret;
    setC(0);

    ret = trytocatch(ui->input1->toPlainText(), ui);
    ret = trytocatch(ui->input2->toPlainText(), ui);
    ret = trytocatch(ui->input3->toPlainText(), ui);
    ret = trytocatch(ui->input11->toPlainText(), ui);
    ret = trytocatch(ui->input12->toPlainText(), ui);
    ret = trytocatch(ui->input13->toPlainText(), ui);

    if (ui->input1->toPlainText()=="1"){
        setC(getC() + 1);
    }
    if(ui->input2->toPlainText()=="0"){
         setC(getC() + 1);
    }
    if(ui->input3->toPlainText()=="1"){
         setC(getC() + 1);
    }
    if(ui->input11->toPlainText()=="0"){
         setC(getC() + 1);
    }
    if(ui->input12->toPlainText()=="0"){
          setC(getC() + 1);
    }
    if(ui->input13->toPlainText()=="0"){
           setC(getC() + 1);
    }

    storage.push_back(getC());

    if(getC() >=4){
       ui->score->setText("nice!");
     }
    else
     {
       ui->score->setText(QString::number(getC()));
      }


}


void facts::on_save_clicked()
{
    ofstream out;
    out.open("save.txt");

    for(int i = 0; i < storage.size();i++){
        out << "your score is: " << storage[i] << endl;
    }

    QMessageBox::information(this, "save", "Your score is save!");

    out.close();
}


void facts::on_pushButton_2_clicked()
{
    secondPage secondpage;
    secondpage.setModal(true);
    secondpage.exec();
}

