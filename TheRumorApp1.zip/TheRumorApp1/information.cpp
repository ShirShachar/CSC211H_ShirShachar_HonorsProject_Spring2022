#include "information.h"
#include "ui_information.h"

information::information(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::information)
{
    ui->setupUi(this);
    ui->linkLabel->setOpenExternalLinks(true);
    ui->linkLabel->setText("<a href=\"https://bit.ly/3KIXTet\">Article 1</a>");
    ui->linkLabel_2->setOpenExternalLinks(true);
    ui->linkLabel_2->setText("<a href=\"https://bit.ly/3shAtWW\">Article 2</a>");
    ui->linkLabel_3->setOpenExternalLinks(true);
    ui->linkLabel_3->setText("<a href=\"https://wapo.st/386TODv\">Article 3</a>");
    ui->linkLabel_4->setOpenExternalLinks(true);
    ui->linkLabel_4->setText("<a href=\"https://cnn.it/3ykdjDq\">Article 4</a>");
}

information::~information()
{
    delete ui;
}

void information::on_pushButton_clicked()
{

}

