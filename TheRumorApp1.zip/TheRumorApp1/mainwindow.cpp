#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "login.h"
#include <fstream>
#include <QMessageBox>
#include <QFile>
#include <vector>
using namespace std;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{

   ui->input1->setText("save");
   ui->input2->setText("save");
   ui->input3->setText("save");
   ui->input4->setText("save");
   ui->input5->setText("********");

   login login;
   login.setModal(true);
   login.exec();



}


void MainWindow::on_auto_2_clicked()
{
    QFile inputFile(":/img/logininput.txt");
    if (inputFile.open(QIODevice::ReadOnly))
    {
       QTextStream in(&inputFile);
       while (!in.atEnd())
       {
          QString line = in.readLine();
         input.push_back(line);
       }
    }
    inputFile.close();

    ui->input1->setText(input[0]);
    ui->input2->setText(input[1]);
    ui->input3->setText(input[2]);
    ui->input4->setText(input[3]);
    ui->input5->setText(input[4]);
}

