#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "about.h"
#include "facts.h"
#include "information.h"
#include "login.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}




//void MainWindow::on_pushButton_3_clicked()
//{
//   QMessageBox::information(this,
//                           tr("Rumor Game"),
//                            tr("Direction to the rumor game"));
//    facts facts;
//    facts.setModal(true);
//    facts.exec();
//}


//void MainWindow::on_aboutpushbutton_clicked()
//{
//    about about;
//    about.setModal(true);
//    about.exec();
//}


void MainWindow::on_pushButton_clicked()
{
   login login;
    login.setModal(true);
    login.exec();
}


//void MainWindow::on_pushButton_2_clicked()
//{
//    login login;
//    login.setModal(true);
//    login.exec();
//}

