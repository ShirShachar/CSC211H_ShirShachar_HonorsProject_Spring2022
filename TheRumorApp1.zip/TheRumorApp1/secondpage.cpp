#include "secondpage.h"
#include "ui_secondpage.h"
#include "thirdPage.h"
#include <iostream>
#include <fstream>
#include <QMessageBox>
#include <vector>

using namespace std;


secondPage::secondPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::secondPage)
{
    ui->setupUi(this);
}

secondPage::~secondPage()
{
    delete ui;
}

bool is_answer_valid2(QString input){
    if(input == "0" || input == "1"){
        return true;
    }
    return false;
}

int trytocatch(QString input, Ui::secondPage* var){
    bool ret;

    try{
    ret = is_answer_valid2(input);
    }
    catch (string msg){
    var->label->setText("this input is not accepted");
    }
    return ret;
}


void secondPage::on_pushButton_clicked()
{
    int count =0;

    bool ret;

    ret = trytocatch(ui->input1->toPlainText(), ui);
    ret = trytocatch(ui->input2->toPlainText(), ui);
    ret = trytocatch(ui->input3->toPlainText(), ui);
    ret = trytocatch(ui->input4->toPlainText(), ui);
    ret = trytocatch(ui->input5->toPlainText(), ui);
    ret = trytocatch(ui->input6->toPlainText(), ui);


    if (ui->input1->toPlainText()=="1"){
        count +=1;
       // ui->fact1->setText("Nice!");
    }
    if(ui->input2->toPlainText()=="1"){
        count+=1;
    }
    if(ui->input3->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input4->toPlainText()=="0"){
        count+=1;
    }
    if(ui->input5->toPlainText()=="1"){
        count+=1;
    }
    if(ui->input6->toPlainText()=="1"){
        count+=1;
    }

    storage.push_back(count);

    if(count >=4){
       ui->score->setText("nice!");
     }
    else
     {
       ui->score->setText(QString::number(count));
      }


}


void secondPage::on_save_clicked()
{
    //ifstream in;
    ofstream out;
    out.open("save.txt");

    for(int i = 0; i < storage.size();i++){
        out << "your score is: " << storage[i] << endl;
    }

    QMessageBox::information(this, "save", "Your score is save!");

    out.close();
}


void secondPage::on_pushButton_2_clicked()
{
    thirdPage thirdpage;
    thirdpage.setModal(true);
    thirdpage.exec();
}

